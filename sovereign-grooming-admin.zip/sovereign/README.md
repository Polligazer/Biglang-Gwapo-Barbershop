# Sovereign Grooming Co. — Admin (PHP 8 + MySQL + vanilla JS + Tailwind CDN)

Built from the "Barber" Figma file (Admin Dashboard, Appointments, Service Management, Inventory & Stock, Admin Login).

## Setup
1. `mysql -u root -p < schema.sql` (creates DB `sovereign_grooming` with sample data)
2. Set DB credentials via env vars `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` (or edit defaults in `db.php`).
   Use a dedicated MySQL user, not root.
3. Create your admin: `php seed_admin.php admin "a-long-password" "Your Name"`
4. Serve: `php -S localhost:8000` (from this folder) → open `/login.php`. On Apache/XAMPP, drop the folder in `htdocs`.

## Layout
- `db.php` — PDO connection (try/catch, exceptions, native prepared statements)
- `lib/core.php` — session, CSRF, JSON/error handling, server-side validation
- `lib/resources.php` — one registry defining fields, filters and business rules per resource
- `lib/crud.php` — generic read / save / remove used by every endpoint
- `api/read|create|update|delete.php` — JSON CRUD for `appointments`, `services`, `inventory` (+ `barbers` read-only)
- `api/adjust_stock.php`, `api/stats.php`, `api/auth.php`
- `index.php`, `login.php`, `assets/app.js` — UI (modals, Fetch API, DOM updates without reloads)

## Rules enforced in PHP
- Appointments: end time derived from service duration; must fit 09:00–18:00; 15-minute slots; no past bookings;
  no overlapping pending/confirmed bookings for one barber (row-locked inside a transaction, so simultaneous requests can't double-book).
- Inventory: stock never goes negative; every change is written to `stock_ledger`; stock is only editable through adjustments.
- Services in use by appointments can't be deleted (hide them instead).
- All writes require POST + session + CSRF token; login is rate-limited per session.
